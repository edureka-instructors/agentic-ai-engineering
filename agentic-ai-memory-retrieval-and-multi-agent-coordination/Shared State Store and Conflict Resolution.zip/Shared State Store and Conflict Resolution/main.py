from collections import Counter
from datetime import datetime

# SHARED STATE STORE
class SharedStateStore:
    def __init__(self):
        self.state = {}
        self.history = []

    def write(self, agent_name, key, value, confidence):
        update = {
            "agent": agent_name,
            "key": key,
            "value": value,
            "confidence": confidence,
            "timestamp": datetime.now().isoformat()
        }

        if key not in self.state:
            self.state[key] = []

        self.state[key].append(update)
        self.history.append(update)

        print(f"\n[{agent_name}] wrote to shared state")
        print(f"Key: {key}")
        print(f"Value: {value}")
        print(f"Confidence: {confidence}")

    def read(self, key):
        return self.state.get(key, [])

    def show_state(self):
        print("\nCURRENT SHARED STATE")
        for key, updates in self.state.items():
            print(f"\nKey: {key}")
            for update in updates:
                print(
                    f"  Agent: {update['agent']} | "
                    f"Value: {update['value']} | "
                    f"Confidence: {update['confidence']}"
                )


# AGENT
class Agent:
    def __init__(self, name, store):
        self.name = name
        self.store = store

    def submit_decision(self, key, value, confidence):
        self.store.write(
            agent_name=self.name,
            key=key,
            value=value,
            confidence=confidence
        )

# CONFLICT RESOLVER
class ConflictResolver:
    def __init__(self, store):
        self.store = store

    def resolve_by_voting(self, key):
        updates = self.store.read(key)

        if not updates:
            return None

        votes = [update["value"] for update in updates]
        vote_counts = Counter(votes)

        winning_value, winning_votes = vote_counts.most_common(1)[0]

        return {
            "method": "voting",
            "final_value": winning_value,
            "votes": winning_votes,
            "vote_distribution": dict(vote_counts)
        }

    def resolve_by_arbitration(self, key):
        updates = self.store.read(key)

        if not updates:
            return None

        best_update = max(
            updates,
            key=lambda item: item["confidence"]
        )

        return {
            "method": "arbitration",
            "final_value": best_update["value"],
            "chosen_agent": best_update["agent"],
            "confidence": best_update["confidence"]
        }

    def resolve(self, key):
        updates = self.store.read(key)

        if not updates:
            return "No updates found for this key."

        unique_values = set(update["value"] for update in updates)

        print("\nCONFLICT CHECK")
        print(f"Values submitted for '{key}': {list(unique_values)}")

        if len(unique_values) == 1:
            return {
                "status": "no_conflict",
                "final_value": updates[0]["value"],
                "reason": "All agents agreed on the same value."
            }

        print("\nConflict detected. Applying voting...")
        voting_result = self.resolve_by_voting(key)

        vote_counts = voting_result["vote_distribution"]
        top_vote_count = max(vote_counts.values())

        tied_values = [
            value for value, count in vote_counts.items()
            if count == top_vote_count
        ]

        if len(tied_values) == 1:
            voting_result["status"] = "resolved_by_voting"
            return voting_result

        print("Voting resulted in a tie. Applying arbitration...")
        arbitration_result = self.resolve_by_arbitration(key)
        arbitration_result["status"] = "resolved_by_arbitration"

        return arbitration_result

# MAIN PROGRAM
if __name__ == "__main__":

    print("DEMO: Shared State Store and Conflict Resolution")

    store = SharedStateStore()

    agent_a = Agent("Agent A - Researcher", store)
    agent_b = Agent("Agent B - Analyst", store)
    agent_c = Agent("Agent C - Reviewer", store)

    resolver = ConflictResolver(store)

    print("\nScenario: Agents are deciding the final risk level for an AI output.")

    agent_a.submit_decision(
        key="risk_level",
        value="Medium",
        confidence=0.72
    )

    agent_b.submit_decision(
        key="risk_level",
        value="High",
        confidence=0.81
    )

    agent_c.submit_decision(
        key="risk_level",
        value="High",
        confidence=0.68
    )

    store.show_state()

    final_result = resolver.resolve("risk_level")

    print("\nFINAL RESOLUTION")
    print(final_result)
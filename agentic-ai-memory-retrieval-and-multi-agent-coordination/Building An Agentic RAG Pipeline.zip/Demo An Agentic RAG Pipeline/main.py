from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# KNOWLEDGE SOURCES

DATA_SOURCES = {
    "Product Docs": [
        """
        Agentic RAG allows an AI system to decide which source should be queried,
        what information should be retrieved, and whether additional retrieval
        is needed before generating a final answer.
        """,
        """
        Retrieval Augmented Generation combines search with language models.
        Modern systems may use vector search, keyword search, reranking,
        and source selection.
        """
    ],

    "Governance Policies": [
        """
        AI-generated responses should be evaluated for relevance, completeness,
        grounding, and accuracy before being delivered to users.
        """,
        """
        If retrieval confidence is low, the system should perform another
        retrieval step or request clarification from the user.
        """
    ],

    "Support Tickets": [
        """
        A user reported that the answer was generated without enough supporting
        evidence. The issue was resolved by adding a retrieval quality evaluation step.
        """,
        """
        A governance question was incorrectly routed to product documentation.
        The solution was intent-based source selection.
        """
    ]
}


# AGENT

class AgenticRAG:

    def __init__(self):
        self.sources = DATA_SOURCES

    # Decide where to search
    def select_sources(self, query):

        query = query.lower()

        selected = []

        if any(word in query for word in
               ["policy", "governance", "audit", "compliance"]):
            selected.append("Governance Policies")

        if any(word in query for word in
               ["rag", "retrieval", "agent", "feature"]):
            selected.append("Product Docs")

        if any(word in query for word in
               ["issue", "problem", "ticket", "error"]):
            selected.append("Support Tickets")

        if not selected:
            selected.append("Product Docs")

        return selected

    # Retrieve
    def retrieve(self, query, source_name, top_k=1):

        docs = self.sources[source_name]

        vectorizer = TfidfVectorizer(stop_words="english")

        vectors = vectorizer.fit_transform(docs + [query])

        similarities = cosine_similarity(
            vectors[-1],
            vectors[:-1]
        ).flatten()

        ranked = sorted(
            zip(docs, similarities),
            key=lambda x: x[1],
            reverse=True
        )

        return ranked[:top_k]

    # Evaluate Retrieval Quality
    def evaluate(self, results):

        if not results:
            return 0

        avg_score = sum(score for _, score in results) / len(results)

        return round(avg_score, 2)

    # Generate Final Answer
    def generate_answer(self, query, context):

        return f"""
Question:
{query}

Answer:
The agent first analyzes the query, selects the most relevant knowledge source,
retrieves supporting information, evaluates retrieval quality, and performs
additional retrieval when confidence is low.

Retrieved Context:
{context}
"""

    # Complete Agent Workflow
    def run(self, query):

        print("\nSTEP 1: Understanding Query")
        print(query)

        selected_sources = self.select_sources(query)

        print("\nSTEP 2: Source Selection")
        print(selected_sources)

        retrieved_results = []

        print("\nSTEP 3: First Retrieval")

        for source in selected_sources:

            results = self.retrieve(query, source)

            for doc, score in results:
                retrieved_results.append((doc, score))

                print(
                    f"Retrieved from [{source}] "
                    f"(score={score:.2f})"
                )

        quality = self.evaluate(retrieved_results)

        print("\nSTEP 4: Quality Evaluation")
        print(f"Quality Score = {quality}")

        # Agent decides if more retrieval is needed
        if quality < 0.20:

            print("\nSTEP 5: Low Confidence Detected")
            print("Agent performing additional retrieval...")

            for source in self.sources:

                if source not in selected_sources:

                    results = self.retrieve(
                        query,
                        source,
                        top_k=1
                    )

                    retrieved_results.extend(results)

        else:
            print("\nSTEP 5: Retrieval Quality Acceptable")

        context = "\n".join(
            doc.strip()
            for doc, _ in retrieved_results
        )

        print("\nSTEP 6: Final Answer Generation")

        return self.generate_answer(
            query,
            context
        )


# MAIN

if __name__ == "__main__":

    agent = AgenticRAG()

    query = input("\nAsk a question: ")

    answer = agent.run(query)

    print("\n" + "=" * 60)
    print("FINAL RESPONSE")
    print("=" * 60)
    print(answer)
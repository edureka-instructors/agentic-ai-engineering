from rich.console import Console

console = Console()

def log_step(title: str, content: str):
    console.rule(f"[bold blue]{title}")
    console.print(content)

from agent import Agent
from utils import log_step

def main():
    log_step("MCP Context Management Demo", "Demonstrating structured context sharing between agent and MCP.")
    agent = Agent()

    while True:
        prompt = input("\nEnter a command (or type 'exit'): ").strip()
        if prompt.lower() == "exit":
            break
        agent.process_prompt(prompt)

    log_step("Demo Complete", "You just simulated structured context management with MCP-like behavior.")

if __name__ == "__main__":
    main()

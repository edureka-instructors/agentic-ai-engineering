from utils import log_step
from context_manager import ContextManager

class Agent:
    """A simple agent that interacts with the MCP-style context manager."""

    def __init__(self):
        self.context_manager = ContextManager()

    def process_prompt(self, prompt: str):
        log_step("Received Prompt", prompt)

        # Simple command parser for MCP operations
        if prompt.startswith("/set"):
            parts = prompt.split(maxsplit=2)
            if len(parts) == 3:
                key, value = parts[1], parts[2]
                result = self.context_manager.update_context(key, value)
            else:
                result = "Usage: /set <key> <value>"

        elif prompt.startswith("/get"):
            parts = prompt.split(maxsplit=1)
            if len(parts) == 2:
                key = parts[1]
                result = self.context_manager.get_context(key)
            else:
                result = "Usage: /get <key>"

        elif prompt == "/show":
            result = str(self.context_manager.show_context())

        elif prompt == "/clear":
            result = self.context_manager.clear_context()

        else:
            # Use context in reasoning (simulate)
            context_data = self.context_manager.show_context()
            if context_data:
                result = f"Responding with context: {context_data}"
            else:
                result = "No context set. Use /set to define one first."

        log_step("Agent Response", result)
        return result

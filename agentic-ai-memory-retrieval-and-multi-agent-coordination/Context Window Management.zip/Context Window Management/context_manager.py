class ContextManager:
    """Simulates an MCP-style structured context manager."""

    def __init__(self):
        self.context = {}

    def update_context(self, key: str, value: str):
        """Add or update context data."""
        self.context[key] = value
        return f"Context updated: {key} = {value}"

    def get_context(self, key: str):
        """Retrieve a value by key."""
        return self.context.get(key, "No context found for this key.")

    def clear_context(self):
        """Clear all stored context."""
        self.context = {}
        return "All context cleared."

    def show_context(self):
        """Return current context as a dictionary."""
        return self.context
        

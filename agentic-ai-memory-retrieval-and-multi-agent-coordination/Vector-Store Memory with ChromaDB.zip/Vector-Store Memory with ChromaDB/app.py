import os
from typing import List, Tuple, Dict, Any

from dotenv import load_dotenv

from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

from langchain_google_genai import (
    ChatGoogleGenerativeAI,
    GoogleGenerativeAIEmbeddings,
)

from langchain_community.vectorstores import FAISS


# Bootstrap: environment, LLM, Embeddings
def build_llm_and_embeddings():
    """
    Load GOOGLE_API_KEY from .env and construct:
    - ChatGoogleGenerativeAI (Gemini)
    - GoogleGenerativeAIEmbeddings for vector memory
    """

    load_dotenv()
    api_key = os.getenv("GOOGLE_API_KEY")

    if not api_key:
        raise RuntimeError("GOOGLE_API_KEY not set in .env")

    llm = ChatGoogleGenerativeAI(
        model="gemini-2.5-flash",
        temperature=0.2,
    )

    embeddings = GoogleGenerativeAIEmbeddings(
        model="models/text-embedding-004"
    )

    return llm, embeddings


llm, embeddings = build_llm_and_embeddings()


# Seed project memory
SEED_MEMORIES: List[Dict[str, Any]] = [
    {
        "text": "Project Atlas is our internal platform for automating deployment pipelines.",
        "metadata": {"topic": "project_overview"},
    },
    {
        "text": "Atlas exposes a REST API built with FastAPI and uses PostgreSQL as the primary database.",
        "metadata": {"topic": "architecture"},
    },
    {
        "text": "We deploy Atlas to Kubernetes with separate staging and production clusters.",
        "metadata": {"topic": "infrastructure"},
    },
    {
        "text": "The biggest performance issue so far has been slow queries on the audit_log table.",
        "metadata": {"topic": "performance"},
    },
    {
        "text": "Our next major milestone for Atlas is adding role-based access control and audit dashboards.",
        "metadata": {"topic": "roadmap"},
    },
]


def build_vector_store() -> FAISS:
    """
    Build an in-memory FAISS vector store from seed project documents.
    """

    docs = [
        Document(
            page_content=m["text"],
            metadata=m["metadata"],
        )
        for m in SEED_MEMORIES
    ]

    vectorstore = FAISS.from_documents(docs, embeddings)
    return vectorstore


VECTORSTORE = build_vector_store()


def adaptive_select_docs(
    docs_with_scores: List[Tuple[Document, float]],
    max_distance: float = 0.5,
    margin: float = 0.05,
    max_items: int = 4,
) -> Tuple[List[Document], Dict[str, Any]]:
    """
    FAISS similarity_search_with_score returns document-distance pairs.
    Lower distance means a better semantic match.
    """

    if not docs_with_scores:
        debug = {
            "best_distance": None,
            "cutoff": None,
            "selected_distances": [],
        }
        return [], debug

    best_doc, best_distance = docs_with_scores[0]

    if best_distance > max_distance:
        debug = {
            "best_distance": best_distance,
            "cutoff": max_distance,
            "selected_distances": [],
        }
        return [], debug

    cutoff = min(best_distance + margin, max_distance)

    selected_docs: List[Document] = []
    selected_distances: List[float] = []

    for doc, distance in docs_with_scores:
        if distance <= cutoff and len(selected_docs) < max_items:
            selected_docs.append(doc)
            selected_distances.append(distance)

    debug = {
        "best_distance": best_distance,
        "cutoff": cutoff,
        "selected_distances": selected_distances,
    }

    return selected_docs, debug


def route_question(question: str) -> Tuple[str, List[Document], Dict[str, Any]]:
    """
    Adaptive routing function.

    Routes to:
    - vector route if relevant project memory is found
    - general route if no relevant memory is found
    """

    docs_with_scores = VECTORSTORE.similarity_search_with_score(question, k=5)

    selected_docs, debug = adaptive_select_docs(docs_with_scores)

    if selected_docs:
        route = "vector"
    else:
        route = "general"

    debug["all_distances"] = [score for _, score in docs_with_scores]

    return route, selected_docs, debug


# Vector-aware QA chain
vector_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            (
                "You are a helpful software engineering assistant working on Project Atlas.\n"
                "You receive project notes as context. Use ONLY this context when answering "
                "questions about Atlas. If something is not in the notes, say that you are unsure.\n\n"
                "Project notes:\n{context}\n"
            ),
        ),
        ("human", "Question: {question}"),
    ]
)

vector_chain = (
    {
        "question": lambda x: x["question"],
        "context": lambda x: x["context"],
    }
    | vector_prompt
    | llm
    | StrOutputParser()
)


# General QA chain
general_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            (
                "You are a general-purpose helpful assistant.\n"
                "You DO NOT have access to project-specific internal notes.\n"
                "Answer broadly, and if the user asks about a specific internal system, "
                "explain that you don't have detailed internal context."
            ),
        ),
        ("human", "Question: {question}"),
    ]
)

general_chain = (
    {
        "question": lambda x: x["question"],
    }
    | general_prompt
    | llm
    | StrOutputParser()
)


def answer_with_routing(question: str) -> Tuple[str, str, Dict[str, Any]]:
    """
    Decide the route and run the corresponding chain.
    """

    route, docs, debug = route_question(question)

    if route == "vector":
        context = "\n".join(
            f"- {doc.page_content}" for doc in docs
        )

        answer = vector_chain.invoke(
            {
                "question": question,
                "context": context,
            }
        )

    else:
        answer = general_chain.invoke(
            {
                "question": question,
            }
        )

    return route, answer, debug


def print_header():
    print("=" * 80)
    print("Vector Memory Architecture and Adaptive Routing")
    print("=" * 80)
    print("Type 'exit' or 'quit' to stop.\n")


def main():
    print_header()

    while True:
        try:
            question = input("Enter the Question: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nExiting. Goodbye!")
            break

        if not question:
            continue

        if question.lower() in {"exit", "quit"}:
            print("Exiting. Goodbye!")
            break

        route, answer, debug = answer_with_routing(question)

        print("\n[Routing]")
        print(f"  -> Route chosen: {route.upper()}")
        print("  -> Debug info:")
        print(f"      best_distance:      {debug.get('best_distance')}")
        print(f"      cutoff:             {debug.get('cutoff')}")
        print(f"      selected_distances: {debug.get('selected_distances')}")
        print(f"      all_distances:      {debug.get('all_distances')}\n")

        print("[Answer]")
        print(answer)
        print("\n" + "-" * 80 + "\n")


if __name__ == "__main__":
    main()
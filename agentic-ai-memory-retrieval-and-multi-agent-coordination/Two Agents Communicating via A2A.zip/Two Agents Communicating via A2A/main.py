import uuid
from datetime import datetime

# STANDARD A2A MESSAGE FORMAT
def create_a2a_message(sender, receiver, task_type, payload):
    return {
        "message_id": str(uuid.uuid4()),
        "timestamp": datetime.now().isoformat(),
        "sender": sender,
        "receiver": receiver,
        "task_type": task_type,
        "payload": payload,
        "status": "sent"
    }

# AGENT B: VERIFIER
class VerifierAgent:

    def __init__(self):
        self.name = "Verifier Agent"

        self.verified_facts = {
            "rag": "RAG stands for Retrieval-Augmented Generation.",
            "a2a": "A2A means Agent-to-Agent communication.",
            "agentic ai": "Agentic AI can plan, decide, and take actions toward a goal.",
            "fact-checking": "Fact-checking validates claims against trusted information sources."
        }

    def receive_message(self, message):
        print("\n[Agent B] Message Received")
        print(f"From: {message['sender']}")
        print(f"Task: {message['task_type']}")

        if message["task_type"] == "fact_check":
            return self.fact_check(message)

        return create_a2a_message(
            sender=self.name,
            receiver=message["sender"],
            task_type="error",
            payload={"result": "Unsupported task type"}
        )

    def fact_check(self, message):
        claim = message["payload"]["claim"].lower()

        print("\n[Agent B] Fact-checking claim...")
        print(f"Claim: {claim}")

        for keyword, verified_fact in self.verified_facts.items():
            if keyword in claim:
                result = {
                    "claim": message["payload"]["claim"],
                    "verification_status": "verified",
                    "evidence": verified_fact
                }

                return create_a2a_message(
                    sender=self.name,
                    receiver=message["sender"],
                    task_type="fact_check_result",
                    payload=result
                )

        result = {
            "claim": message["payload"]["claim"],
            "verification_status": "not_verified",
            "evidence": "No matching trusted fact was found."
        }

        return create_a2a_message(
            sender=self.name,
            receiver=message["sender"],
            task_type="fact_check_result",
            payload=result
        )

# AGENT A: RESEARCHER
class ResearcherAgent:

    def __init__(self, verifier_agent):
        self.name = "Researcher Agent"
        self.verifier = verifier_agent

    def research_topic(self, topic):
        print("\n[Agent A] Researching topic...")
        print(f"Topic: {topic}")

        draft_claims = [
            f"{topic} helps AI systems work more autonomously.",
            "A2A means Agent-to-Agent communication.",
            "RAG stands for Retrieval-Augmented Generation."
        ]

        verified_claims = []

        for claim in draft_claims:
            print("\n[Agent A] Delegating fact-checking to Agent B")

            message = create_a2a_message(
                sender=self.name,
                receiver=self.verifier.name,
                task_type="fact_check",
                payload={"claim": claim}
            )

            print("\nStandard A2A Message Sent:")
            print(message)

            response = self.verifier.receive_message(message)

            print("\nStandard A2A Response Received:")
            print(response)

            if response["payload"]["verification_status"] == "verified":
                verified_claims.append(response["payload"])

        return self.generate_summary(topic, verified_claims)

    def generate_summary(self, topic, verified_claims):
        print("\n[Agent A] Generating final research summary...")

        summary = f"\nResearch Summary on: {topic}\n"
        summary += "-" * 50 + "\n"

        if not verified_claims:
            summary += "No claims were verified.\n"
            return summary

        for item in verified_claims:
            summary += f"\nClaim: {item['claim']}"
            summary += f"\nStatus: {item['verification_status']}"
            summary += f"\nEvidence: {item['evidence']}\n"

        return summary

# MAIN PROGRAM
if __name__ == "__main__":

    verifier = VerifierAgent()
    researcher = ResearcherAgent(verifier)

    print("DEMO: Two Agents Communicating via A2A")

    topic = input("\nEnter a research topic: ")

    final_summary = researcher.research_topic(topic)

    print(final_summary)
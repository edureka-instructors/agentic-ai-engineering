import os
from typing import TypedDict, List, Dict

from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from langgraph.graph import StateGraph, START, END

# LOAD ENVIRONMENT VARIABLES
load_dotenv()

# Optional verification
print("Gemini Key Loaded:",
      "Yes" if os.getenv("GEMINI_API_KEY") else "No")

# GEMINI MODEL
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash-lite",
    google_api_key=os.getenv("GEMINI_API_KEY")
)

# STATE
class AgentState(TypedDict):
    task: str
    selected_agents: List[str]
    agent_outputs: Dict[str, str]
    final_response: str

# SUPERVISOR ROUTER
def supervisor_router(state: AgentState):

    task = state["task"]
    task_lower = task.lower()

    selected_agents = []

    if any(word in task_lower for word in
           ["research", "find", "explore", "study"]):
        selected_agents.append("researcher")

    if any(word in task_lower for word in
           ["analyze", "compare", "evaluate", "risk", "impact"]):
        selected_agents.append("analyst")

    if any(word in task_lower for word in
           ["write", "summarize", "report", "explain", "draft"]):
        selected_agents.append("writer")

    if not selected_agents:
        selected_agents = [
            "researcher",
            "analyst",
            "writer"
        ]

    print("\nSTEP 1: Supervisor Understanding Task")
    print(task)

    print("\nSTEP 2: Supervisor Routing Task")
    print(selected_agents)

    return {
        "selected_agents": selected_agents,
        "agent_outputs": {}
    }

# RESEARCHER AGENT
def researcher_agent(state: AgentState):

    if "researcher" not in state["selected_agents"]:
        return {}

    print("\nRunning Researcher Agent...")

    prompt = f"""
You are a Researcher Agent.

Gather key information, background context,
and important facts related to the task.

Task:
{state["task"]}

Return concise research findings.
"""

    response = llm.invoke(prompt)

    outputs = dict(state["agent_outputs"])
    outputs["Researcher Agent"] = response.content

    print("Researcher Agent completed.")

    return {
        "agent_outputs": outputs
    }

# ANALYST AGENT
def analyst_agent(state: AgentState):

    if "analyst" not in state["selected_agents"]:
        return {}

    print("\nRunning Analyst Agent...")

    prompt = f"""
You are an Analyst Agent.

Analyze the task.

Identify:
- Benefits
- Risks
- Patterns
- Business Implications

Task:
{state["task"]}

Return a clear analysis.
"""

    response = llm.invoke(prompt)

    outputs = dict(state["agent_outputs"])
    outputs["Analyst Agent"] = response.content

    print("Analyst Agent completed.")

    return {
        "agent_outputs": outputs
    }

# WRITER AGENT
def writer_agent(state: AgentState):

    if "writer" not in state["selected_agents"]:
        return {}

    print("\nRunning Writer Agent...")

    prompt = f"""
You are a Writer Agent.

Create a clear, structured,
beginner-friendly report.

Task:
{state["task"]}

Return a well-organized response.
"""

    response = llm.invoke(prompt)

    outputs = dict(state["agent_outputs"])
    outputs["Writer Agent"] = response.content

    print("Writer Agent completed.")

    return {
        "agent_outputs": outputs
    }

# SUPERVISOR SYNTHESIS
def supervisor_synthesizer(state: AgentState):

    print("\nSTEP 3: Supervisor Monitoring Outputs")

    for agent_name in state["agent_outputs"]:
        print(f"{agent_name} output received.")

    combined_outputs = ""

    for agent_name, output in state["agent_outputs"].items():

        combined_outputs += f"""

{agent_name} Output:
{output}
"""

    print("\nSTEP 4: Supervisor Synthesizing Final Answer")

    prompt = f"""
You are a Supervisor Agent.

Review all specialist outputs.

Responsibilities:

1. Remove repetition
2. Combine insights
3. Produce one final response

Original Task:
{state["task"]}

Specialist Outputs:
{combined_outputs}

Generate the final consolidated response.
"""

    response = llm.invoke(prompt)

    return {
        "final_response": response.content
    }

# BUILD LANGGRAPH WORKFLOW
graph = StateGraph(AgentState)

graph.add_node(
    "supervisor_router",
    supervisor_router
)

graph.add_node(
    "researcher",
    researcher_agent
)

graph.add_node(
    "analyst",
    analyst_agent
)

graph.add_node(
    "writer",
    writer_agent
)

graph.add_node(
    "supervisor_synthesizer",
    supervisor_synthesizer
)

graph.add_edge(
    START,
    "supervisor_router"
)

graph.add_edge(
    "supervisor_router",
    "researcher"
)

graph.add_edge(
    "researcher",
    "analyst"
)

graph.add_edge(
    "analyst",
    "writer"
)

graph.add_edge(
    "writer",
    "supervisor_synthesizer"
)

graph.add_edge(
    "supervisor_synthesizer",
    END
)

app = graph.compile()

# MAIN
print("\nSupervisor Multi-Agent System with LangGraph\n")

user_task = input(
    "Enter a complex AI-related task: "
)

initial_state = {
    "task": user_task,
    "selected_agents": [],
    "agent_outputs": {},
    "final_response": ""
}

try:

    result = app.invoke(initial_state)

    print("\n" + "=" * 60)
    print("FINAL SUPERVISOR RESPONSE")
    print("=" * 60)

    print(result["final_response"])

except Exception as error:

    print("\nError:")
    print(error)
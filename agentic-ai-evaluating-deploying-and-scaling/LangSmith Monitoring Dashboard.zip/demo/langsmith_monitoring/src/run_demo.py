from dotenv import load_dotenv
from app import ask_agent


load_dotenv()


def main():
    print("\nStarting LangSmith Monitoring Demo with Gemini...\n")
    print("Type your question and press Enter.")
    print("Type 'exit' to stop the demo.\n")

    while True:
        question = input("Ask a question: ")

        if question.lower() == "exit":
            print("\nDemo completed.")
            print("Now open LangSmith and check the project:")
            print("support-agent-monitoring-gemini-demo")
            break

        print("-" * 80)

        try:
            response = ask_agent(question)

            messages = response.get("messages", [])
            if messages:
                print(messages[-1].content)
            else:
                print(response)

        except Exception as error:
            print("Demo error captured:")
            print(error)

        print("-" * 80)


if __name__ == "__main__":
    main()
from dotenv import load_dotenv

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.agents import create_agent

from tools import get_order_status


load_dotenv()


def create_support_agent():
    """
    Creates a simple Gemini-powered customer support agent.
    """

    model = ChatGoogleGenerativeAI(
        model="gemini-2.5-flash",
        temperature=0
    )

    agent = create_agent(
        model=model,
        tools=[get_order_status],
        system_prompt="""
        You are a helpful customer support assistant.

        You can answer general customer support questions.
        If the user asks about an order status, use the get_order_status tool.
        Keep answers clear and professional.
        """
    )

    return agent


def ask_agent(question: str):
    """
    Sends a user question to the support agent.
    """

    agent = create_support_agent()

    response = agent.invoke(
        {
            "messages": [
                {
                    "role": "user",
                    "content": question
                }
            ]
        }
    )

    return response
from langchain_core.tools import tool


@tool
def get_order_status(order_id: str) -> str:
    """
    Get the delivery status of a customer order.
    """

    if order_id == "000":
        raise ValueError("Invalid order ID. Order 000 does not exist.")

    sample_orders = {
        "12345": "Order 12345 is out for delivery and will arrive today.",
        "45678": "Order 45678 has been shipped and will arrive in 2 days.",
        "99999": "Order 99999 is delayed due to a logistics issue.",
    }

    return sample_orders.get(
        order_id,
        f"Order {order_id} was not found in the demo database."
    )

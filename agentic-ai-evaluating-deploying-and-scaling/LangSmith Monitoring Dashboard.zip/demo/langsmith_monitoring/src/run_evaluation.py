from dotenv import load_dotenv
from langsmith import evaluate

from app import ask_agent


load_dotenv()


examples = [
    {
        "inputs": {
            "question": "What is your return policy?"
        },
        "outputs": {
            "expected_keywords": ["return", "policy"]
        }
    },
    {
        "inputs": {
            "question": "Can you check the status of order 12345?"
        },
        "outputs": {
            "expected_keywords": ["12345", "delivery"]
        }
    },
    {
        "inputs": {
            "question": "Give me a short answer about the exchange policy."
        },
        "outputs": {
            "expected_keywords": ["exchange"]
        }
    }
]


def target(inputs: dict) -> dict:
    """
    Target function that LangSmith evaluates.
    """

    question = inputs["question"]
    response = ask_agent(question)

    messages = response.get("messages", [])
    final_message = messages[-1].content if messages else str(response)

    return {
        "answer": final_message
    }


def keyword_score(run, example) -> dict:
    """
    Simple keyword-based evaluator for demo purposes.
    """

    answer = run.outputs.get("answer", "").lower()
    expected_keywords = example.outputs.get("expected_keywords", [])

    matched_keywords = [
        keyword for keyword in expected_keywords
        if keyword.lower() in answer
    ]

    if len(expected_keywords) == 0:
        score = 0
    else:
        score = len(matched_keywords) / len(expected_keywords)

    return {
        "key": "keyword_match_score",
        "score": score,
        "comment": f"Matched keywords: {matched_keywords}"
    }


def main():
    print("\nRunning LangSmith evaluation with Gemini...\n")

    results = evaluate(
        target,
        data=examples,
        evaluators=[keyword_score],
        experiment_prefix="support-agent-gemini-quality-eval"
    )

    print("Evaluation completed.")
    print(results)


if __name__ == "__main__":
    main()